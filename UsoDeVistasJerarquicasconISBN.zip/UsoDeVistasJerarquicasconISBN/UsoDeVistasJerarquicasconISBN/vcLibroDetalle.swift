//
//  vcLibroDetalle.swift
//  UsoDeVistasJerarquicasconISBN
//
//  Created by Juan Felipe Chávez on 10/09/16.
//  Copyright © 2016 JuanFelipeChávez. All rights reserved.
//

import UIKit

class vcLibroDetalle: UIViewController {

    var codigo = String()

    @IBOutlet weak var lblTitulo: UILabel!
    @IBOutlet weak var imgPortada: UIImageView!
    @IBOutlet weak var lblautor: UILabel!
    @IBOutlet weak var lblISBN: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()


          BusquedadeISBN(codigo)
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    func BusquedadeISBN(pISBN: String) {

        lblISBN.text = "ISBN: " + pISBN


        let urls =  "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:" + pISBN
        let url =  NSURL(string: urls)
        //let datos:NSData? =  NSData(contentsOfURL: url!)
        let datos = NSData(contentsOfURL: url!)

        if datos == nil{
            //txtvwResultados.text = "No se encontraron Datos. Esto puede ser porque el ISBN no existe o no tiene conexion de Internet persistente"

            let alertController = UIAlertController(title: "Error", message:"Se ha producido un error de comunicación.", preferredStyle: UIAlertControllerStyle.Alert)

            alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default,handler: nil))

            self.presentViewController(alertController, animated: true, completion: nil)

        }else{

            //En esta parte mandaba antes el texto en crudo, aqui va a componer el texto para que traiga sólo lo que quiere.


            /* let texto =  NSString(data:datos!, encoding:NSUTF8StringEncoding)
             txtvwResultados.text = texto! as String */


            do{
                let json = try NSJSONSerialization.JSONObjectWithData(datos!, options: NSJSONReadingOptions.MutableContainers)

                let dico1 = json as! NSDictionary

                if (dico1["ISBN:" + pISBN] as? NSDictionary) != nil
                {
                    let dico2 = dico1["ISBN:" + pISBN] as! NSDictionary
                    let titulo =  dico2["title"] as! NSString as String
                    lblTitulo.text = "Titulo: " + titulo


                }
                else{

                    let alertController = UIAlertController(title: "Sin resultados", message:"No existe el libro, favor de revisar la consulta.", preferredStyle: UIAlertControllerStyle.Alert)

                    alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default,handler: nil))

                    self.presentViewController(alertController, animated: true, completion: nil)

                }

                let dico11 = json as! NSDictionary
                if (dico1["ISBN:" + pISBN] as? NSDictionary) != nil
                {
                    let dico22 = dico11["ISBN:" + pISBN] as! NSDictionary
                    let ItemArray = dico22["authors"] as! NSArray

                    for item in ItemArray {
                        let nameArray  = item["name"]!
                        lblautor.text = ("Autor: \(nameArray!)")
                    }
                }else{


                    let alertController = UIAlertController(title: "Sin resultados", message:"No existe el libro, favor de revisar la consulta.", preferredStyle: UIAlertControllerStyle.Alert)
                    alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default,handler: nil))
                    self.presentViewController(alertController, animated: true, completion: nil)
                }

                //Here we are going to fectch a search to find a cover

                let dico111 = json as! NSDictionary
                if (dico1["ISBN:" + pISBN] as? NSDictionary) != nil
                {
                    let dico222 = dico111["ISBN:" + pISBN] as! NSDictionary
                    if (dico222["cover"] as? NSDictionary) != nil
                    {
                        let dico333 = dico222["cover"] as! NSDictionary
                        let urlPortada = NSURL(string: dico333["small"] as! String)
                        let dataPortada = NSData(contentsOfURL: urlPortada!)

                        print(UIImage(data: dataPortada!))
                        self.imgPortada.image = UIImage(data: dataPortada!)



                    }else{
                        // self.lblPortada.text = "No se encontro portada"
                        self.imgPortada.image = nil
                    }
                }else{
                    let alertController = UIAlertController(title: "Sin resultados", message:"No existe el libro, favor de revisar la consulta.", preferredStyle: UIAlertControllerStyle.Alert)

                    alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default,handler: nil))

                    self.presentViewController(alertController, animated: true, completion: nil)
                }

                //Try to fill the struct



            }
            catch {
                
                let alertController = UIAlertController(title: "Error", message:"Se ha producido un error de datos en la lectura de Json.", preferredStyle: UIAlertControllerStyle.Alert)
                
                alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default,handler: nil))
                
                self.presentViewController(alertController, animated: true, completion: nil)
                
                
            }
            
            
        }

        return
        
    }


}
