//
//  tvcContenedorDeBusquedas.swift
//  UsoDeVistasJerarquicasconISBN
//
//  Created by Juan Felipe Chávez on 10/09/16.
//  Copyright © 2016 JuanFelipeChávez. All rights reserved.
//

import UIKit

private let reuseIdentifier = "Cell"

    var libro = [Seccion]()
    var libroapp = [Seccion]()

struct Seccion{
    var ISBN: String


    init(ISBN : String ){
        self.ISBN = ISBN
    }
}
var librosArr : Array<Array<String>> = Array<Array<String>>()

class tvcContenedorDeBusquedas: UITableViewController {


    var resultado = String()
    

    @IBOutlet weak var txtISBN: UITextField!
    @IBOutlet var appsTableView: UITableView!
    @IBOutlet weak var txt_Busqueda: UITextField!
    @IBAction func txt_Busqueda(sender: UITextField) {

        do{
            let resultados : String = try sincrono(sender.text!)
            if resultados != ""{
                let seccion =  Seccion(ISBN: resultados)
                libro.append(seccion)
            self.appsTableView.reloadData()
            }
        }
        catch
        {

            let alertController = UIAlertController(title: "Error", message:"Ocurrió un error que no esperabamos. UPS!", preferredStyle: UIAlertControllerStyle.Alert)

            alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default,handler: nil))

            self.presentViewController(alertController, animated: true, completion: nil)


        }
        txt_Busqueda.text = ""



    }

    @IBAction func btn_Busqueda(sender: UIBarButtonItem) {

        let v = txt_Busqueda

        do{
            let resultados : String = try sincrono(v.text!)
            if resultados != ""{
                let seccion =  Seccion(ISBN: resultados)
                libro.append(seccion)
            }
        }
        catch
        {

            let alertController = UIAlertController(title: "Error", message:"Ocurrió un error que no esperabamos. UPS!", preferredStyle: UIAlertControllerStyle.Alert)

            alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default,handler: nil))

            self.presentViewController(alertController, animated: true, completion: nil)


        }
        txt_Busqueda.text = ""
        self.appsTableView.reloadData()


    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return libro.count
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return libro.count
    }


    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath)

        // Configure the cell...
        cell.textLabel?.text = libro[indexPath.section].ISBN
        

        return cell
    }

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.

       // let cc = segue.destinationViewController as! vcDetallesLibro

        if let cell = sender as? UITableViewCell {
            let i = appsTableView.indexPathForCell(cell)!.row
                if segue.identifier == "toDetails"{

                     let cc = segue.destinationViewController as! vcLibroDetalle
                     cc.codigo = libro[i].ISBN

            }

        }


    }


    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        //i = indexPath.row
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */




    func sincrono(pISBN: String) throws -> String {

        var valorRetorno = String()


        let urls =  "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:" + pISBN
        let url =  NSURL(string: urls)
        //let datos:NSData? =  NSData(contentsOfURL: url!)
        let datos = NSData(contentsOfURL: url!)

        if datos == nil{
            //txtvwResultados.text = "No se encontraron Datos. Esto puede ser porque el ISBN no existe o no tiene conexion de Internet persistente"

            let alertController = UIAlertController(title: "Error", message:"Se ha producido un error de comunicación.", preferredStyle: UIAlertControllerStyle.Alert)

            alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default,handler: nil))

            self.presentViewController(alertController, animated: true, completion: nil)

        }else{

            //En esta parte mandaba antes el texto en crudo, aqui va a componer el texto para que traiga sólo lo que quiere.


            /* let texto =  NSString(data:datos!, encoding:NSUTF8StringEncoding)
             txtvwResultados.text = texto! as String */


            do{
                let json = try NSJSONSerialization.JSONObjectWithData(datos!, options: NSJSONReadingOptions.MutableContainers)

                let dico1 = json as! NSDictionary

                if (dico1["ISBN:" + pISBN] as? NSDictionary) != nil
                {
                    let dico2 = dico1["ISBN:" + pISBN] as! NSDictionary

                    print(dico2["title"] as! NSString as String)
                    // self.lblTitulo.text = dico2["title"] as! NSString as String

                    valorRetorno = dico2["title"] as! NSString as String
                  //  nombreLibro = dico2["title"] as! NSString as String
                  

                }
                else{

                    let alertController = UIAlertController(title: "Sin resultados", message:"No existe el libro, favor de revisar la consulta.", preferredStyle: UIAlertControllerStyle.Alert)

                    alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default,handler: nil))

                    self.presentViewController(alertController, animated: true, completion: nil)

                }

                let dico11 = json as! NSDictionary
                if (dico1["ISBN:" + pISBN] as? NSDictionary) != nil
                {
                    let dico22 = dico11["ISBN:" + pISBN] as! NSDictionary
                    let ItemArray = dico22["authors"] as! NSArray

                    for item in ItemArray {
                        let nameArray  = item["name"]!

                      //  print("Autor: \(nameArray!)")
                      //  nombreAutor = ("Autor: \(nameArray!)")
                    }
                }else{


                    let alertController = UIAlertController(title: "Sin resultados", message:"No existe el libro, favor de revisar la consulta.", preferredStyle: UIAlertControllerStyle.Alert)
                    alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default,handler: nil))
                    self.presentViewController(alertController, animated: true, completion: nil)
                }

                //Here we are going to fectch a search to find a cover

                let dico111 = json as! NSDictionary
                if (dico1["ISBN:" + pISBN] as? NSDictionary) != nil
                {
                    let dico222 = dico111["ISBN:" + pISBN] as! NSDictionary
                    if (dico222["cover"] as? NSDictionary) != nil
                    {
                        let dico333 = dico222["cover"] as! NSDictionary
                        // self.lblPortada.text = dico333["small"] as! NSString as String
                        let urlPortada = NSURL(string: dico333["small"] as! String)
                        let dataPortada = NSData(contentsOfURL: urlPortada!)

                        print(UIImage(data: dataPortada!))
                        //self.ImgPortada.image = UIImage(data: dataPortada!)
                        //imagenPortada = UIImage(data: dataPortada!)!
                        //Aqui va la imàgen


                    }else{
                        // self.lblPortada.text = "No se encontro portada"
                        // ImgPortada.image = nil
                    }
                }else{
                    let alertController = UIAlertController(title: "Sin resultados", message:"No existe el libro, favor de revisar la consulta.", preferredStyle: UIAlertControllerStyle.Alert)

                    alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default,handler: nil))

                    self.presentViewController(alertController, animated: true, completion: nil)
                }

           //Try to fill the struct



            }
            catch {

                let alertController = UIAlertController(title: "Error", message:"Se ha producido un error de datos en la lectura de Json.", preferredStyle: UIAlertControllerStyle.Alert)
                
                alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default,handler: nil))
                
                self.presentViewController(alertController, animated: true, completion: nil)
                
                
            }


        }

        if valorRetorno != "" {
            valorRetorno = pISBN
        }

        
        return valorRetorno
        
    }
    


}
